
$(function() {
	//适应屏幕
	function fontSize(){
		var w=$(window).width();
		w=w>1920?1920:w;
		$("html").css("fontSize",w/19.2 +"px");
	}
	fontSize();
	window.onresize=fontSize;
	
	function getM(){
		var url = window.location.href;	
		var arr = url.split("#");
		console.log(arr)
		if( arr.length == 1 ){
           return false
		}else{
		var p = arr[1].split("?");
		console.log(p)
	 	var m = p[0];
		return m;
	    }
	}
	
	

	function router(m,$con){
		$con=$con||$("#content")
		$.ajax({
			url:"views/"+m+".html",
			success:function(data){
				console.log($("#content"));
				$con.html(data);


			}
		});
	};
	
	if(getM()){
		console.log(1111);
		router(getM());

	}else{
        console.log(2222);
		router("indexcontent");

		
	}


	// 导航
	$('.nav .item').hover(function() {
		$(this).addClass('active');
		$(this).find('.child-nav').show();
	}, function() {
		$(this).removeClass('active');
		$(this).find('.child-nav').hide();
	});

   //  返回顶部  
	$(window).scroll(function(){
		var sc=$(window).scrollTop();
		var rwidth=$(window).width()
		if(sc>150){
		 $(".b-and-qq").css("display","block");
		}else{
		$(".b-and-qq").css("display","none");
		}
	  })
	  $(".back").click(function(){
		var sc=$(window).scrollTop();
		$('body,html').animate({scrollTop:0},500);
	  });


	//   获取省市
	  for(let i=0;i < sheng_list.length; i++){
		  $("<option>").html(sheng_list[i].name).attr("value",sheng_list[i].value).appendTo($("#sheng"));		
	  };
	  $("#sheng").change(function(e){
		  let arr_shi_list = [];
		  for(let i = 0; i < shi_list.length;i++){
              if($("#sheng").val() == shi_list[i].zubie){
				  arr_shi_list.push(shi_list[i])
			  }
		  };
		  $("#shi").html("");
		  for(let i=0;i < arr_shi_list.length; i++){			
			$("<option>").html(arr_shi_list[i].name).attr("value",arr_shi_list[i].value).appendTo($("#shi"));		
		  };
	  })

	  // 登陆、报名 显示模态层
	  $("#login").click(function(){
		$('#myModal').modal('show');
		$(".mo-login-cont").show();
		$(".mo-reg-cont").hide();
		$(".triangle").css("left","140px");
		$(".mo-login").css({"background": "#18b0be","color":" #fff"});
		$(".mo-reg").css({"background": "#d0ecef","color":" #333"});

	  });	  
	  $("#register").click(function(){
		$('#myModal').modal('show');
		$(".mo-login-cont").hide();
		$(".mo-reg-cont").show();
		$(".triangle").css("left","430px");
		$(".mo-login").css({"background": "#d0ecef","color":" #333"});
		$(".mo-reg").css({"background": "#18b0be","color":" #fff"});
	  });




});

