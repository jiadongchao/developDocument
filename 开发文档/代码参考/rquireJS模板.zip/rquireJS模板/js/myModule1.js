/**
 * Created by Administrator on 2017/9/29.
 */
define(function (){
 var showInfor = function (msg){
    alert(msg)
  };
  return {
    showInfor: showInfor
  };
});