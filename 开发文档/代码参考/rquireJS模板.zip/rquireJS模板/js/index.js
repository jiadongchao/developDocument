/**
 * Created by Administrator on 2017/9/29.
 */
requirejs.config({
  baseUrl: "js",
  paths: {

    "jquery": "../../lib/jquery-1.11.3.min",
    "layer": "../../lib/layer-v3.1.0/layer/layer",
    "common": "../../js/common",
    "myModule1":"../../js/myModule1",
    "myModule2":"../../js/myModule2"

  },
  shim: {
    "layer": ["jquery"],
    "common": ["layer", "jquery"],
  }
});

require(["jquery", "layer","common","myModule1","myModule2"],function ($,layer,common,myModule1,myModule2) {


  $("#btn0").on("click",function(){
    alert("this is index.js")
  });
  $("#btn1").on("click",function(){
    common.test()
  });
  $("#btn2").on("click",function(){
    layer.alert("this is layer")
  });
  $("#btn3").on("click",function(){
    myModule1.showInfor("我是模块1")
  });
  $("#btn4").on("click",function(){
    myModule2.showMsg2()
  });

})