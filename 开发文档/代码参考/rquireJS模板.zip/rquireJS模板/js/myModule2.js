/**
 * Created by Administrator on 2017/9/29.
 */
define(function (){

  return {
    showMsg2 :function(){
      alert("this is 模块2")
    }

  }
});