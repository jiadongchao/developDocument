//适应屏幕
function fontSize(){
	var w=$(window).width();
	w=w>750?750:w;
	$("html").css("fontSize",w/3.2 +"px");
}
fontSize();
window.onresize=fontSize;
//url转json
function parseQueryString(){
	var url=window.location.href;
	var obj={};
	var keyvalue=[];
	var key="",value="";
	var paraString=url.substr(url.indexOf("?")+1,url.length).split("&");
	for(var i in paraString){
		keyvalue=paraString[i].split("=");
		key=keyvalue[0];
		value=keyvalue[1];
		obj[key]=value;
	};
	return obj;
};
//模块的url
function getM(){
	var url = window.location.href;
	var arr = url.split("#");
	var p = arr[1].split("?");
	var m = p[0];
	return m;
}


//
function router(m,$con){
	$con=$con||$("#share")
	$.ajax({
		url:"views/"+m+".html",
		success:function(data){
			$con.html(data);
			loadjs(m);
		}
	});
};
function loadjs(m){
	$.ajax({
		url:"js/"+m+".js"
	});
}

$(function(){
	if(!localStorage.count){
		localStorage.count=0;
	};
	localStorage.count++;
	if(localStorage.count==1){
		router("hello");
	}else{
	router("tab");
//		router("sing");
		router("audio",$("#global"));
	};
})
