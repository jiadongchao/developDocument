$(function(){
	//在tab引进去之后 引入home
	router("v0",$("#con"));
	//切换home
	$("nav li").click(function(){
		$("nav li").removeClass("act");
		$(this).addClass("act");
		router("v"+$(this).index(),$("#con"));
	})
})
