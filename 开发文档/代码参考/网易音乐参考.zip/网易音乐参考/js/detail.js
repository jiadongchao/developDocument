var param=parseQueryString();
$(".back").click(function(){
	router("tab");
})
//歌曲列表
function getlist(callback){
	$.ajax({
		type:"get",
		url:"data/playlist.json",
		success:function(data){
			callback(data.playlist.tracks);
		}
	});
};
getlist(function(list){
	var item=$("#songbox2").html();
	for(var i=0;i<list.length;i++){
		var $item=$(item);
		$item.find("h4").html(list[i].name);
		$item.find("p").html(list[i].ar[0].name);
		$item.find(".order").html(i+1);
		$item.data("music",list[i]);
		$item.click(function(){
			router("sing");
			$("#global").show();
			$("#btn .pause").removeClass("play");
			mControlor.play($(this).data("music").id);
			$("#global").find("h4").html($(this).data("music").name);
			$("#global").find("p").html($(this).data("music").ar[0].name);
			$("#global").find("img").attr("src",$(this).data("music").al.picUrl);
		}).appendTo(".songlist2");
	}
});
//title tag
function getPlaylist2(callback){
	$.ajax({
		url:"data/topPlayList.json",
		success:function(data){
			callback(data.playlists);
		}
	});
};
getPlaylist2(function(list){
	var id=parseQueryString().id;
	for(var i=0;i<list.length;i++){
		if(list[i].id==id){
			$(".bglist").find(".count").html(list[i].playCount);
			$(".bglist").find(".des").html(list[i].name);
			$(".bglist").find(".big").attr("src",list[i].coverImgUrl);
			$(".bglist").find(".name").html(list[i].creator.nickname);
			$(".bglist").find(".small").attr("src",list[i].creator.avatarUrl);
			$(".bglist").css("backgroundImage","url("+list[i].creator.backgroundUrl+")")
			$(".taglist").find(".des").html("简介："+list[i].description);
			for(var j=0;j<list[i].tags.length;j++){
				$("<span>").html(list[i].tags[j]).appendTo(".taglist .tag");
			};
		};
	};
});